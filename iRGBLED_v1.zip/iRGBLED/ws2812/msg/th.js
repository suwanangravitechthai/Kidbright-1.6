Blockly.Msg.NEOPIXEL_INIT_MESSAGE = "iRGBLED เริ่มต้นใช้งานที่ขา %1 ความยาว %2 ดวง โหมดสี %3";
Blockly.Msg.NEOPIXEL_INIT_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_SET_BRIGHTNESS_MESSAGE = "iRGBLED ขา %1 กำหนดความสว่าง %2 %";
Blockly.Msg.NEOPIXEL_SET_BRIGHTNESS_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_SET_PIXEL_MESSAGE = "iRGBLED ขา %1 กำหนดดวงที่ %2 เป็นสี %3";
Blockly.Msg.NEOPIXEL_SET_PIXEL_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_SET_PIXEL_RGB_MESSAGE = "iRGBLED ขา %1 กำหนดดวงที่ %2 เป็นสี rgb( %3 , %4 , %5 )";
Blockly.Msg.NEOPIXEL_SET_PIXEL_RGB_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_FILL_MESSAGE = "iRGBLED ขา %1 กำหนดสีทุกดวงเป็น %2";
Blockly.Msg.NEOPIXEL_FILL_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_FILL_RGB_MESSAGE = "iRGBLED ขา %1 กำหนดสีทุกดวงเป็น rgb( %2 , %3 , %4 )";
Blockly.Msg.NEOPIXEL_FILL_RGB_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_SHOW_MESSAGE = "iRGBLED ขา %1 แสดงผล";
Blockly.Msg.NEOPIXEL_SHOW_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_CLEAR_MESSAGE = "iRGBLED ขา %1 ล้างค่า";
Blockly.Msg.NEOPIXEL_CLEAR_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_RAINBOW_MESSAGE = "iRGBLED ขา %1 สว่างไล่สี หน่วงเวลา (ms) %2";
Blockly.Msg.NEOPIXEL_RAINBOW_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_RAINBOW_CYCLE_MESSAGE = "iRGBLED ขา %1 สว่างไล่สีแบบวงรอบ หน่วงเวลา (ms) %2";
Blockly.Msg.NEOPIXEL_RAINBOW_CYCLE_TOOLTIP = "";
