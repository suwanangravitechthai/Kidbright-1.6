Blockly.Msg.NEOPIXEL_INIT_MESSAGE = "iRGBLED initialize pin %1 length %2 mode %3";
Blockly.Msg.NEOPIXEL_INIT_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_SET_BRIGHTNESS_MESSAGE = "iRGBLED pin %1 set brightness %2 %";
Blockly.Msg.NEOPIXEL_SET_BRIGHTNESS_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_SET_PIXEL_MESSAGE = "iRGBLED pin %1 set pixel %2 color %3";
Blockly.Msg.NEOPIXEL_SET_PIXEL_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_SET_PIXEL_RGB_MESSAGE = "iRGBLED pin %1 set pixel %2 color rgb( %3 , %4 , %5 )";
Blockly.Msg.NEOPIXEL_SET_PIXEL_RGB_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_FILL_MESSAGE = "iRGBLED pin %1 fill all LED color %2";
Blockly.Msg.NEOPIXEL_FILL_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_FILL_RGB_MESSAGE = "iRGBLED pin %1 fill all LED color rgb( %2 , %3 , %4 )";
Blockly.Msg.NEOPIXEL_FILL_RGB_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_SHOW_MESSAGE = "iRGBLED pin %1 show";
Blockly.Msg.NEOPIXEL_SHOW_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_CLEAR_MESSAGE = "iRGBLED pin %1 clear";
Blockly.Msg.NEOPIXEL_CLEAR_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_RAINBOW_MESSAGE = "iRGBLED pin %1 rainbow Time(ms) %2";
Blockly.Msg.NEOPIXEL_RAINBOW_TOOLTIP = "";

Blockly.Msg.NEOPIXEL_RAINBOW_CYCLE_MESSAGE = "iRGBLED pin %1 rainbow cycle Time(ms) %2";
Blockly.Msg.NEOPIXEL_RAINBOW_CYCLE_TOOLTIP = "";
