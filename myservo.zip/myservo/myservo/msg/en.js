Blockly.Msg.MYSERVO = {
	// myservo
	"Servo pin": "Servo pin",
	"set angle to": "set angle to",
	"Give angle to your servo motor": "Give angle to your servo motor",
	
	// Direction
	"calibrate time to": "calibrate time to",
	"Calibration your servo motor": "Calibration your servo motor"
};
