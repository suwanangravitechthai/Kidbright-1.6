Blockly.Msg.MYSERVO = {
	// myservo
	"Servo pin": "เซอร์โวมอเตอร์ขา",
	"set angle to": "ให้หมุนไปที่",
	"Give angle to your servo motor": "ใช้กำหนดองศาที่ต้องการให้เซอร์โวมอเตอร์หมุนไป",
	
	// Direction
	"calibrate time to": "ตั้งค่าเวลาไปที่",
	"Calibration your servo motor": "ปรับแต่งค่าเวลา เพื่อให้เซอร์โวมอเตอร์ทำงานถูกต้อง"
};
