Blockly.Msg.MPU6050_ACC_MESSAGE = "MPU-6050 อ่านค่าความเร่ง (mg) %1";
Blockly.Msg.MPU6050_ACC_TOOLTIP = "";

Blockly.Msg.MPU6050_GYRO_MESSAGE = "MPU-6050 อ่านค่าไจโรสโคป (°) %1";
Blockly.Msg.MPU6050_GYRO_TOOLTIP = "";

Blockly.Msg.MPU6050_TEMP_MESSAGE = "MPU-6050 อ่านค่าอุณหภูมิ (°C)";
Blockly.Msg.MPU6050_TEMP_TOOLTIP = "";

Blockly.Msg.MPU6050_ACC_SET_RANGE_MESSAGE = "MPU-6050 ตั้งค่าช่วงวัดความเร่ง %1";
Blockly.Msg.MPU6050_ACC_SET_RANGE_TOOLTIP = "";

Blockly.Msg.MPU6050_GYRO_SET_RANGE_MESSAGE = "MPU-6050 ตั้งค่าช่วงวัดไจโรสโคป %1";
Blockly.Msg.MPU6050_GYRO_SET_RANGE_TOOLTIP = "";
